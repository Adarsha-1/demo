package com.cg.java.services;

public class EmpServices {
	private String companyName;
	private String address;
	private float yrlyPackage;
	private SalaryServices services;
	
	public EmpServices()
	{
		System.out.println("EmpService object created");
	}
	public EmpServices(String companyName,String address)
	{
		super();
		System.out.println("2 parameters are called");
		this.companyName=companyName;
		this.address=address;
	}
	public EmpServices(String companyName,String address,float yrlyPackage)
	{
		super();
		System.out.println("3 parameters are called");
		this.companyName=companyName;
		this.address=address;
		this.yrlyPackage=yrlyPackage;
	}
	
	
	public String getMessage()
	{
		System.out.println(services.calcSalary());
		return "Welcome Spring training " + companyName;
	}
	//properties are always extracted from getter setter methods by removing the get and set from function name and changing names into camel convention while using in xml file.
	public String getCompanyName() { //companyName
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getAddress() {//address
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public SalaryServices getServices() {
		return services;
	}
	public void setServices(SalaryServices services) {
		this.services = services;
	}
	
	

}
