package com.cg.java.services;

public class SalaryServices {
	public SalaryServices()
	{
		System.out.println("Object SalaryServices object creted.");
	}
	public String calcSalary()
	{
		return "Salary calculated";
	}
}
