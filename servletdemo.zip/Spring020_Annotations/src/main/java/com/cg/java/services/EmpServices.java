package com.cg.java.services;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/*
 * The interface IntializatingBean imposes implementation of method 
 * 			afterPropertiesSet(). This method gets call automatically after setting all properties.
 * The interface DisposableBean imposes implementation of method
 * 			destroy(). This method gets automatically called while bean is removed from Spring context.
 */

@Component("empServices")
public class EmpServices{// implements InitializingBean, DisposableBean{
	@Value("Capgemini, Pune")//Intital hardcoded value
	private String companyName;
	
	@Value("Talawdae")
	private String address;
	
	@Value("896578")
	private float yrlyPackage;
	
	@Autowired//this is field injection when it is done in set function then it is setter injection and in constructor(only the particular field should be there) it is constructor injection
	private SalaryServices services;
	
	public EmpServices()
	{
		System.out.println("EmpService object created");
	}
	public EmpServices(String companyName,String address)
	{
		super();
		System.out.println("2 parameters are called");
		this.companyName=companyName;
		this.address=address;
	}
	public EmpServices(String companyName,String address,float yrlyPackage)
	{
		super();
		System.out.println("3 parameters are called");
		this.companyName=companyName;
		this.address=address;
		this.yrlyPackage=yrlyPackage;
	}
	
	
	public String getMessage()
	{
		System.out.println(services.calcSalary());
		return "Welcome Spring training " + companyName;
	}
	//properties are always extracted from getter setter methods by removing the get and set from function name and changing names into camel convention while using in xml file.
	public String getCompanyName() { //companyName
		return companyName;
	}
	
	@Value("Cap,Pune")
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getAddress() {//address
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public SalaryServices getServices() {
		return services;
	}
	
	//@Autowired 
	//byType: Find the bean as per the type and not on "Id".
	//byName: Find the bean on the basis of id.For this @Qualifier("") is used to specify the id i.e the class component name
	//@Qualifier("salaryService")
	public void setServices(SalaryServices services) {
		this.services = services;
	}
	
	@PostConstruct// is used when it doesn't implements IntializingBean
	public void afterPropertiesSet() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("In afterPropertiesSet()");
	}
	
	@PreDestroy// is used when it doesn't implements DisposableBean
	public void destroy() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Destroy method is called");
	}
	
}
