package com.cg.java.services;

import org.springframework.stereotype.Component;

@Component("salaryServices")
public class SalaryServices {
	public SalaryServices()
	{
		System.out.println("Object SalaryServices creted.");
	}
	public String calcSalary()
	{
		return "Salary calculated";
	}
}
