package com.cg.java.services;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service("salaryServices")
public class SalaryServices {
	public SalaryServices()
	{
		System.out.println("Object SalaryServices creted.");
	}
	public String calcSalary()
	{
		return "Salary calculated";
	}
}
