package com.cg.java.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.java.dto.Emp;
import com.cg.java.exceptions.EmpException;

@Repository("empDao")
public class EmpDaoImpl implements EmpDao{

	public List<Emp> getEmpList() throws EmpException {
		List<Emp> empList=new ArrayList<Emp>();
		empList.add(new Emp(123,"Adarsha",18000));
		empList.add(new Emp(234,"chintu",58963));
		return empList;
	}

}
