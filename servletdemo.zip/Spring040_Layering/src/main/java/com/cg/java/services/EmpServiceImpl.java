package com.cg.java.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.cg.java.dao.EmpDao;
import com.cg.java.dao.EmpDaoImpl;
import com.cg.java.dto.Emp;
import com.cg.java.exceptions.EmpException;

//@Component("empService")
@Service("empService")
public class EmpServiceImpl implements EmpService{
	@Autowired
	private EmpDao dao;
	//@Qualifier("empDao")
	public List<Emp> getEmpList() throws EmpException {
		// TODO Auto-generated method stub
		return dao.getEmpList();
	}

}
