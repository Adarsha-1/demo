package com.cg.java.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;

import com.cg.java.dao.EmpDao;
import com.cg.java.dao.EmpDaoImpl;
import com.cg.java.services.EmpService;
import com.cg.java.services.EmpServiceImpl;

/*
 * @Configuration: Class level. Declares a class as configuration class. 
 * @Bean: Method Level. Declares a method as a factory method.
 *		A method responsible for initializing an object is a factory method.
 */

@Configuration
public class ProjectConfig {
	
	@Autowired
	ApplicationContext ctx;
	@Bean("empDao")
	//@Scope("prototype")
	//@Lazy(true)
	public EmpDao getEmpDao()
	{
		System.out.println("Bean created");
		return new EmpDaoImpl();
	}
	
	@Bean("empService")
	public EmpService getEmpService()
	{
		EmpDao dao=ctx.getBean("empDao",EmpDao.class);
		EmpService service=new EmpServiceImpl();
		service.setDao(dao);
		System.out.println("new method()");
		return service;
		
	}
}
