package com.cg.java.dao;

import java.util.List;

import com.cg.java.exceptions.EmpException;

public interface SalaryDao {
	public List<EmpSal> getEmpSalList() throws EmpException;

}
