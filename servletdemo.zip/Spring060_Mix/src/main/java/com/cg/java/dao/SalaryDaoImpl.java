package com.cg.java.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.java.exceptions.EmpException;

public class SalaryDaoImpl implements SalaryDao{

	@Override
	public List<EmpSal> getEmpSalList() throws EmpException {
		// TODO Auto-generated method stub
		List<EmpSal> empSalList=new ArrayList<EmpSal>();
		empSalList.add(new EmpSal(123,4500,500));
		empSalList.add(new EmpSal(234,4300,400));
		
		return empSalList;
	}

}
