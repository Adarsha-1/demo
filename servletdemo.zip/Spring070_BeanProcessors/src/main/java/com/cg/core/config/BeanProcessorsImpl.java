package com.cg.core.config;

import java.beans.PropertyDescriptor;

import org.springframework.beans.BeansException;
import org.springframework.beans.PropertyValues;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.beans.factory.config.InstantiationAwareBeanPostProcessor;
import org.springframework.stereotype.Component;

import com.cg.core.dao.EmpDao;
import com.cg.core.dao.EmpDaoImpl;

/*
 * The BeanPostProcessors are created before all other beans.
 * The postProcessBeforeInstantiation() is called for creating EmpDao.
 * If this method returns instance of EmpDaoImpl bean is created.
 * If this method returns null, spring invokes its own bean creation mechanism and creates a bean.
 * 
 * BeanPostProcessor.
 * 		postProcessAfterInitialization()
 * 		postProcessBeforeInitialization()
 * InstantiationAwareBeanPostProcessor: extended from BeanPostProcessor
 * 		postProcessBeforeInstantiation():
 * 		postProcessAfterInstantiation(): 
 * 			Returns true: Does data injection.
 * 			returns false: Bypass data injection. This is called as short circuiting.
 * 		postProcessProperties()
 * 		postProcessPropertyValue()
 * 		
 */
@Component
public class BeanProcessorsImpl implements InstantiationAwareBeanPostProcessor, BeanPostProcessor{

	//1.
	public Object postProcessBeforeInstantiation(Class<?> beanClass, String beanName) throws BeansException {
		// TODO Auto-generated method stub
		/*System.out.println(beanClass.getName() +"  "+beanName);
		EmpDao dao=new EmpDaoImpl();*/
		System.out.println(beanClass.getName() +"  "+beanName);
		/*if(beanName.equals("empDao"))
		{
			EmpDao dao=new EmpDaoImpl();
			return dao;
		}*/
		return null;
	}
	
	//2
	public boolean postProcessAfterInstantiation(Object bean, String beanName) throws BeansException {
		// TODO Auto-generated method stub
		System.out.println("postProcessAfterInstantiation   2");
		return true;
	}

	//It comes from BeanPostProcessor
	//The method can be used to validate injection for a bean.
		public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
			// TODO Auto-generated method stub
			System.out.println("postProcessBeforeInitialization    bean1");
			System.out.println(bean);
			return bean;
		}
	//It comes from BeanPostProcessor. 
	public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
		// TODO Auto-generated method stub
		System.out.println("postProcessAfterInitialization  bean2");
		return bean;
	}
	//3.
	public PropertyValues postProcessPropertyValues(PropertyValues pvs, PropertyDescriptor[] pds, Object bean,
			String beanName) throws BeansException {
		// TODO Auto-generated method stub
		System.out.println("values()");
		return pvs;
	}
	//4
	public PropertyValues postProcessProperties(PropertyValues pvs, Object bean, String beanName)
			throws BeansException {
		// TODO Auto-generated method stub
		System.out.println("properties()");
		return pvs;
	}

	
	
	

	
	
}
