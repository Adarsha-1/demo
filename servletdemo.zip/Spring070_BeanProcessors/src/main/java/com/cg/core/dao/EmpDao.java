package com.cg.core.dao;

public interface EmpDao {

}
