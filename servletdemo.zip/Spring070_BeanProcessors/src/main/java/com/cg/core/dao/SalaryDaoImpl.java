package com.cg.core.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.java.exceptions.EmpException;

@Repository("salaryDao")
public class SalaryDaoImpl implements SalaryDao{


}
