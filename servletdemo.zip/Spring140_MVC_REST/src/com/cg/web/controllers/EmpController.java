package com.cg.web.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cg.core.dto.Emp;
import com.cg.core.exceptions.EmpException;
import com.cg.core.services.EmpService;


//http://localhost:9090/Spring140_MVC_REST/rest/empService/empList
@RestController
@RequestMapping("/empService")
public class EmpController {
	
	@Autowired
	private EmpService service;
	
	@GetMapping(value="/empList",produces="application/json")
	public List<Emp> getEmpList()
	{
		List<Emp> empList=null;
		try {
			empList = service.getEmpList();
		} 
		catch (EmpException e) {
			e.printStackTrace();
		}
		return empList;
	}
}
