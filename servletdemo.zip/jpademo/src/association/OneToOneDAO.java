package association;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class OneToOneDAO {
	
	public void addRecord()
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpa");
		EntityManager em=emf.createEntityManager();
		EmployeeEntityDTO emp=new EmployeeEntityDTO();
		em.getTransaction().begin();
		ParkingEntityDTO park=new ParkingEntityDTO();
		park.setBuildingName("B3");
		park.setPid(3);
		emp.setCity("anantapur");
		emp.setEmpId(1001);
		emp.setEmpName("adar");
		emp.setSalary(45000);
		emp.setParking(park);
		em.persist(emp);
		em.getTransaction().commit();
		em.close();
		emf.close();
		System.out.println("Record Inserted");
	}
	
	public void fetchRecord()
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpa");
		EntityManager em=emf.createEntityManager();
		EmployeeEntityDTO emp=em.find(EmployeeEntityDTO.class, 1001);
		System.out.println(emp.getEmpName());
		System.out.println(emp.getParking().getPid());
	}

}
