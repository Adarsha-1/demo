package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import entity.EmployeeEntity;

public class jpqlDao {
	public void getEmployees()
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpa");
		EntityManager em=emf.createEntityManager();
		Query q=em.createQuery("select e from EmployeeEntity e where city like 'bangalore'"); 
		List<EmployeeEntity> li=q.getResultList();
		for(EmployeeEntity emp:li)
		{
			System.out.println(emp.getCity());
			System.out.println(emp.geteName());
		}
		
		Query q1=em.createQuery("delete from EmployeeEntity where empId=?1 and city like ?2");
		em.getTransaction().begin();
		q1.setParameter(1, 5001);
		q1.setParameter(2, "Hyderabad");
		int re=q1.executeUpdate();
		em.getTransaction().commit();
		System.out.println("row is deleted: "+re);
		Query q2=em.createQuery("from EmployeeEntity");
		List<EmployeeEntity> list=q2.getResultList();
		
		TypedQuery<EmployeeEntity> q3=em.createQuery("from EmployeeEntity where empId=6001",EmployeeEntity.class);
		EmployeeEntity result=q3.getSingleResult();
		
		Query q4=em.createQuery("select empId,salary from EmployeeEntity where city like 'Hyderabad'");
		TypedQuery<String> q5=em.createQuery("select empName from EmployeeEntity where salary>?1",String.class);
		q5.setParameter(1,5600);
		em.close();
		emf.close();
	}

}
