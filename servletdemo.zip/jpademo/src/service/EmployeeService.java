package service;

import dao.EmployeeDAO;
import dto.EmployeeDTO;

public class EmployeeService {
	public void addEmployee(EmployeeDTO emp)
	{
		new EmployeeDAO().addEmployee(emp);
	}
	
	public void getEmployee(int empid)
	{
		new EmployeeDAO().getEmployee(empid);
	}
	
	public void updateEmployee(int empId,String newCity)
	{
		new EmployeeDAO().updateEmployee(empId,newCity);
	}
}
