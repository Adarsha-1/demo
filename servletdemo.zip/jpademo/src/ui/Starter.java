package ui;

import java.util.Calendar;

import association.OneToOneDAO;
import dao.jpqlDao;
import dto.EmployeeDTO;
import service.EmployeeService;

public class Starter {
	public static void main(String[] argc)
	{
		EmployeeDTO emp=new EmployeeDTO();
		//emp.setEmpId(6);
		emp.setCity("Hyderabad");
		emp.setEmpName("chintu");
		emp.setSalary(40000);
		emp.setDoj(Calendar.getInstance());
		new EmployeeService().addEmployee(emp);
		//getEmployee();
		//updateEmployee();
		//new jpqlDao().getEmployees();
		//new OneToOneDAO().addRecord();
	}
	public static void getEmployee()
	{
		int empId=1;
		new EmployeeService().getEmployee(empId);
	}
	
	public static void updateEmployee()
	{
		String city="bangalore";
		int empId=6;
		new EmployeeService().updateEmployee(empId,city);
		
	}

}
