package dao;

import model.Login;

public interface LoginDAO {
	String loginCheck(Login loginBean);
}
