package DAO;

import java.util.List;

import DTO.Consumers;


public interface ConsumerDAO {
	List<Consumers> get();
	Consumers serach(int id);
	List<Consumers> show();

}
