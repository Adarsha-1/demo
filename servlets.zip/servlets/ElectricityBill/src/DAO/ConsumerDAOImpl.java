package DAO;

import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.*;
import DTO.Consumers;
import conenction.DBConnectionUtil;

public class ConsumerDAOImpl implements ConsumerDAO {
	Connection connection=null;
	ResultSet resultSet=null;
	Statement stat=null;
	PreparedStatement preparedStatement=null;
	@Override
	public List<Consumers> get() {
		// TODO Auto-generated method stub
		List<Consumers> list=null;
		Consumers cons=null;
		try
		{
			list=new ArrayList<Consumers>();
			String query="SELECT * FROM Consumers";
			connection=DBConnectionUtil.openConnection();
			stat=connection.createStatement();
			resultSet=stat.executeQuery(query);
			while(resultSet.next())
			{
				Consumers con=new Consumers();
				con.setConsNum(resultSet.getInt(1));
				con.setName(resultSet.getString(2));
				con.setAddress(resultSet.getString(3));
				list.add(con);
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public Consumers serach(int id) {
		// TODO Auto-generated method stub
		Consumers con=null;
		try
		{
			con=new Consumers();
			String query="SELECT * FROM Customers WHERE consumer_num="+id;
			connection=DBConnectionUtil.openConnection();
			stat=connection.createStatement();
			resultSet=stat.executeQuery(query);
			if(resultSet.next())
			{
				con.setConsNum(resultSet.getInt(1));
				con.setName(resultSet.getString(2));
				con.setAddress(resultSet.getString(3));
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return con;
	}

	@Override
	public List<Consumers> show() {
		// TODO Auto-generated method stub
		List<Consumers> list=null;
		Consumers cons=null;
		try
		{
			list=new ArrayList<Consumers>();
			String query="SELECT * FROM Consumers";
			connection=DBConnectionUtil.openConnection();
			stat=connection.createStatement();
			resultSet=stat.executeQuery(query);
			while(resultSet.next())
			{
				Consumers con=new Consumers();
				con.setConsNum(resultSet.getInt(1));
				con.setName(resultSet.getString(2));
				con.setAddress(resultSet.getString(3));
				list.add(con);
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return list;
	}

}
