package DTO;

public class Consumers {
	private int consNum;
	private String name;
	private String address;
	public int getConsNum() {
		return consNum;
	}
	public void setConsNum(int consNum) {
		this.consNum = consNum;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Consumers [consNum=" + consNum + ", name=" + name + ", address=" + address + "]";
	}
	
}
