package conenction;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class DBConnectionUtil {
	public static Connection openConnection()
	{
		Connection conn=null;
		FileReader  fr=null;
		Properties props=null;
		try
		{
			fr=new FileReader("resource/oracle.properties");
			props=new Properties();
			props.load(fr);
			System.out.println("No of properties: "+props.size());
			String url=props.getProperty("jdbc.url");
			String username=props.getProperty("jdbc.username");
			String pwd=props.getProperty("jdbc.password");
			System.out.println(url+"user: "+username+"pwd:"+pwd);
			conn=DriverManager.getConnection(url, username, pwd);
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return conn;
	}
}
