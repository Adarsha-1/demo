package service;

public class ConsumerController {

}
