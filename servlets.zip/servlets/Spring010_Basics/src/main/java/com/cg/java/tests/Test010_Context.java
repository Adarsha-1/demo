package com.cg.java.tests;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.java.services.EmpServices;
import com.cg.java.services.SalaryServices;
/*
 * The bean and beans tags come from spring-beans.xsd.
 * the bean rag takes atleast 2 attributes.
 * 		The class attribute:Represents fully qualified name of a class.
 * 		The id attribute: To uniquely identify bean.
 * The ClassPathXmlApplicationContext
 * 		is a Spring Container implementing interface ApplicationContext.
 * On creation of ClassPathXmlApplicationContext...
 * 		refers the configuration file and creates every bean declared there.
 * 		Beans are of 2 types: Singleton and Prototypes.
 * 		Singleton: Object created only once. By default it is singleton.
 * 		Prototype: Object created as and when required.
 * Bean Creation:
 * 		Eager: All beans are created at the time of creation of Spring Context.(when scpoe="protoype" is not mentioned in the XML File where the services are included)
 * 		Lazy: Beans are created on demand only.
 * 		
 * 		Prototype: beans are always created lazily.
 * 		Singleton: Either Eagerly/Lazily
 */

public class Test010_Context {

	public static void main(String[] args) {
		// 1.Create spring context, spring container.
		//the ApplicationContext is modified version of BeanFactory from spring 4.3 onwards it is deprecated.
		ApplicationContext ct=new ClassPathXmlApplicationContext("springCore.xml");
		
		System.out.println("**************");
		EmpServices services1=(EmpServices) ct.getBean("empServices");
		EmpServices services2=(EmpServices) ct.getBean("empServices");
		System.out.println(services1);
		System.out.println(services2.getMessage());
		System.out.println(services1.getAddress());
		
//		SalaryServices services3=(SalaryServices) ct.getBean("salaryServices");
//		System.out.println(services3.calcSalary());
	}

}
