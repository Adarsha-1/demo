package com.cg.java.tests;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.java.services.EmpServices;
import com.cg.java.services.SalaryServices;
/*
 * The bean declaration is done using @Component.
 * The initial value can be hard-coded using @Value.
 * There are 3 types of injection...
 * 		The Field Injection: Give @Autowired to field.
 * 		The Constructor Injection: Give @Autowoired to Constructor.
 *  	The Setter Injection: Give @Autowoired to Setter Method.
 */

public class Test010_Context {

	public static void main(String[] args) {
		// 1.Create spring context, spring container.
		//the ApplicationContext is modified version of BeanFactory from spring 4.3 onwards it is deprecated.
		ApplicationContext ct=new ClassPathXmlApplicationContext("springCore.xml");
		
		System.out.println("**************");
		EmpServices services1=(EmpServices) ct.getBean("empServices");
		EmpServices services2=(EmpServices) ct.getBean("empServices");
		System.out.println(services1.getMessage());
		System.out.println(services2.getMessage());
		System.out.println(services1.getAddress());
		
//		SalaryServices services3=(SalaryServices) ct.getBean("salaryServices");
//		System.out.println(services3.calcSalary());
		
		ConfigurableApplicationContext cctx=(ConfigurableApplicationContext)ct;
		cctx.close();
	}

}
