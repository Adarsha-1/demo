package com.cg.java.services;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/*
 * Spring Lifecycle Interface:
 * The interface IntializatingBean imposes implementation of method 
 * 			afterPropertiesSet(). This method gets call automatically after setting all properties.
 * The interface DisposableBean imposes implementation of method
 * 			destroy(). This method gets automatically called while bean is removed from Spring context.
 * 
 * Bean Lifecycle methods:
 * @PostConstruct: An annotation given by Java.
 * 			It declares an init method for a bean.
 * 			After creating a bean, spring context calls this method automatically.
 * 			It is to create/assign resources.
 * 			This approach allows naming the method suitable to domain activity.
 * @PreDestroy: An annotation given by java.
 * 			It declares a finalizing method for a bean.
 * 			At the time of bean being removed from spring context, this method is automatically gets called. It is to clean resources.
 * 			Method name can be different as per the aim of the method
 * Both annotations come from javax.annotation
 * Both ideally should be preffered over use of Spring Bean Lifecycle interfaces
 * Both are method level annotation
 * 
 * @Scope: To declare 'singleton' or 'prototype' for a bean.
 * @Scope("singleton") or @Scope("prototype")
 * 
 * Each bean by default is created eagerly i.e at the time of creation of spring context
 * @lazy(false): By default creates bean eagerly
 * @lazy(True): Creates a bean lazily only on demand
 * 
 * @Component: To declare a bean.
 * 	The sub-annotations are for documentation purpose.
 * 		@Repository: To declare DAO classes ad bean.
 * 		@Service: To declare business logic/ service bean
 * 		@Controller: To declare controlling classes in Spring MVC.
 * 		@RestController: An annotation to declare REST services from a class in Spring REST.
 */

@Component("empServices")
@Scope("singleton")
@Lazy(true)
public class EmpServices{// implements InitializingBean, DisposableBean{
	@Value("Capgemini, Pune")//Intital hardcoded value
	private String companyName;
	
	@Value("Talawdae")
	private String address;
	
	@Value("896578")
	private float yrlyPackage;
	
	@Autowired//this is field injection when it is done in set function then it is setter injection and in constructor(only the particular field should be there) it is constructor injection
	private SalaryServices services;
	
	public EmpServices()
	{
		System.out.println("EmpService object created");
	}
	public EmpServices(String companyName,String address)
	{
		super();
		System.out.println("2 parameters are called");
		this.companyName=companyName;
		this.address=address;
	}
	public EmpServices(String companyName,String address,float yrlyPackage)
	{
		super();
		System.out.println("3 parameters are called");
		this.companyName=companyName;
		this.address=address;
		this.yrlyPackage=yrlyPackage;
	}
	
	
	public String getMessage()
	{
		System.out.println(services.calcSalary());
		return "Welcome Spring training " + companyName;
	}
	//properties are always extracted from getter setter methods by removing the get and set from function name and changing names into camel convention while using in xml file.
	public String getCompanyName() { //companyName
		return companyName;
	}
	
	@Value("Cap,Pune")
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getAddress() {//address
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public SalaryServices getServices() {
		return services;
	}
	
	//@Autowired 
	//byType: Find the bean as per the type and not on "Id".
	//byName: Find the bean on the basis of id.For this @Qualifier("") is used to specify the id i.e the class component name
	//@Qualifier("salaryService")
	public void setServices(SalaryServices services) {
		this.services = services;
	}
	
	@PostConstruct// is used when it doesn't implements IntializingBean
	public void afterPropertiesSet() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("In afterPropertiesSet()");
	}
	
	@PreDestroy// is used when it doesn't implements DisposableBean
	public void destroy() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Destroy method is called");
	}
	
}
