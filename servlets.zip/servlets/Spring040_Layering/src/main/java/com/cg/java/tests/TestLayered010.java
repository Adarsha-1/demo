
package com.cg.java.tests;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.java.dao.EmpDao;
import com.cg.java.exceptions.EmpException;
import com.cg.java.services.EmpService;

public class TestLayered010 {

	public static void main(String[] args) {
		ConfigurableApplicationContext ctx=new ClassPathXmlApplicationContext("springCore.xml");
		//EmpDao dao=ctx.getBean("empDao",EmpDao.class);
		EmpService service=ctx.getBean("empService", EmpService.class);
		try
		{
			System.out.println(service.getEmpList());
		}
		catch(EmpException e)
		{
			e.printStackTrace();
		}
	}

}
