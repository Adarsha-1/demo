
package com.cg.java.tests;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.java.config.ProjectConfig;
import com.cg.java.dao.EmpDao;
import com.cg.java.exceptions.EmpException;
import com.cg.java.services.EmpService;

public class TestLayered010 {

	public static void main(String[] args) {
		ConfigurableApplicationContext ctx=new AnnotationConfigApplicationContext(ProjectConfig.class);
		System.out.println("******************");
		EmpDao dao=ctx.getBean("empDao",EmpDao.class);
		EmpService dao2=ctx.getBean("empService",EmpService.class);
		try
		{
			System.out.println(dao.getEmpList());
			System.out.println("dao1:"+dao.hashCode());
			System.out.println(dao2.getEmpList());
			System.out.println("Dao2:"+dao2.hashCode());
		}
		catch(EmpException e)
		{
			e.printStackTrace();
		}
		ctx.close();
	}

}
