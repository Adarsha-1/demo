
package com.cg.java.tests;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.java.config.ProjectConfig;
import com.cg.java.dao.EmpDao;
import com.cg.java.exceptions.EmpException;
import com.cg.java.services.EmpService;

public class TestLayered010 {

	public static void main(String[] args) {
		ConfigurableApplicationContext ctx=new AnnotationConfigApplicationContext(ProjectConfig.class);
		System.out.println("******************");
		EmpService service1=ctx.getBean("empService",EmpService.class);
		EmpService service2=ctx.getBean("empService",EmpService.class);
		try
		{
			System.out.println(service1.getEmpList());
			System.out.println(service1.getEmpSalList());
			System.out.println("Service1: "+service1.hashCode());
			System.out.println("Service2:"+service2.hashCode());
		}
		catch(EmpException e)
		{
			e.printStackTrace();
		}
		ctx.close();
	}

}
