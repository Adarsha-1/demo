package com.cg.core.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

@Repository("empDao")
public class EmpDaoImpl implements EmpDao{
	
	@Value("10")
	private int value;
	@Autowired
	private SalaryDao sal;
	
	public EmpDaoImpl()
	{
		System.out.println("empdaoImpl class is called");
	}
	@Override
	public String toString() {
		return "EmpDaoImpl [value=" + value + "]";
	}
	
}
