package com.cg.core.dao;

import java.util.List;

import com.cg.java.exceptions.EmpException;

public interface SalaryDao {

}
