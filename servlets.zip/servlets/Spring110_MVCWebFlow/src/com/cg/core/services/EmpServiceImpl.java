package com.cg.core.services;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

@Service
@Scope("singleton")
public class EmpServiceImpl implements EmpService{

	@Override
	public String authenticate(String userNm, String pwd) {
		// TODO Auto-generated method stub
		if(userNm.equals("ada") && pwd.equals("ada"))
		{
			return "adarsha Reddy";
		}
		return null;
	}
	
}
