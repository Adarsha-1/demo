package com.cg.core.daos;

import java.util.List;

import com.cg.core.dto.Emp;
import com.cg.core.exceptions.EmpException;

public interface EmpDao {
	public List<Emp> getEmpList() throws EmpException;
	public Emp addNewEmp(Emp emp);
}
