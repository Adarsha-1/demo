package com.cg.core.daos;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.core.dto.Emp;
import com.cg.core.exceptions.EmpException;


/*
 * Using connection pool is always a best practice instead of managing single connection
 * Spring support javax.sql.DataSource which is manager for pool of connection.
 *  A DataSourceManager in Spring gives ready connection pool and DataSource.
 */

@Repository("")
public class EmpDaoImpl implements EmpDao{

	@Autowired
	private DataSource dataSource;
	@Override
	public List<Emp> getEmpList() throws EmpException {
		Connection connect=null;
		Statement stmt=null;
		ResultSet rs=null;
		List<Emp> empList=new ArrayList<Emp>();
		String query="SELECT employee_id, first_name, salary FROM employees";
		try {
			connect=dataSource.getConnection();
			stmt=connect.createStatement();
			rs=stmt.executeQuery(query);
			while(rs.next())
			{
				int empNo=rs.getInt(1);
				String name=rs.getString(2);
				float sal=rs.getFloat(3);
				Emp e=new Emp(empNo,name,sal);
				empList.add(e);
			}
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new EmpException("Error while procuring data:",e);//this is called as exception chaining.
		}
		finally
		{
			try {
				if(rs!=null)
				{
					rs.close();
				}
				if(stmt!=null)
				{
					stmt.close();
				}
				if(connect!=null)
				{
					connect.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new EmpException("Error while closing conenction",e);
			}
		}
		
		return empList;
	}
	@Override
	public Emp addNewEmp(Emp emp) {
		// TODO Auto-generated method stub
		return null;
	}

}
