package com.cg.core.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.cg.core.daos.EmpDao;
import com.cg.core.dto.Emp;
import com.cg.core.exceptions.EmpException;

@Service
@Scope("singleton")
public class EmpServiceImpl implements EmpService{

	@Autowired
	private EmpDao dao;
	@Override
	public String authenticate(String userNm, String pwd) {
		// TODO Auto-generated method stub
		if(userNm.equals("ada") && pwd.equals("ada"))
		{
			return "adarsha Reddy";
		}
		return null;
	}

	@Override
	public List<Emp> getEmpList() throws EmpException {
		// TODO Auto-generated method stub
		return dao.getEmpList();
	}
	
}
