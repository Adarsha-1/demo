package com.cg.core.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Employees")
public class Emp {
	
	@Id
	@Column(name="employee_id")
	private int empId;
	
	@Column(name="salary")
	private float salary;
	
	@Column(name="first_name")
	private String firstName;
	
	public Emp()
	{
		
	}
	public Emp(int empId, String firstName, float salary) {
		super();
		this.empId = empId;
		this.salary = salary;
		this.firstName = firstName;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	@Override
	public String toString() {
		return "Emp [empId=" + empId + ", salary=" + salary + ", firstName=" + firstName + "]";
	}
	
}
