package com.cg.web.boot.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.web.boot.dto.Employee;
import com.cg.web.boot.service.EmpService;

//http:localhost:9095/hello

//http:localhost:9095/newEmp
/*
 * {
    "empId": 4,
    "empNm": "yamini",
    "empSal": 15000
  }
 */
@RestController
public class MyRestServices {
	
	@Autowired
	private EmpService service;
	@RequestMapping("/hello")
	public String hello()
	{
		return "Hello";
	}
	
	@RequestMapping(value="/empList", produces="application/json")
	public List<Employee> getEmpList()
	{
		List<Employee> empList=service.getEmpList();
		return empList;
	}
	
	@RequestMapping(value="/newEmp", produces="application/json", consumes="application/json", method=RequestMethod.POST)
	public @ResponseBody Employee joinNewEmployee(@RequestBody Employee emp)
	{
		return service.joinNewEmployee(emp);
	}
}
