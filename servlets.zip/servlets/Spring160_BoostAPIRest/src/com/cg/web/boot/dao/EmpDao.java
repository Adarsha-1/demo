package com.cg.web.boot.dao;

import org.springframework.data.repository.CrudRepository;

import com.cg.web.boot.dto.Employee;

public interface EmpDao extends CrudRepository<Employee,Integer>{
	
}
