package com.cg.web.boot.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employees")
public class Employee {
	@Id
	@Column(name="EMPLOYEE_ID")
	private int empId;
	@Column(name="FIRST_NAME")
	private String empNm;
	@Column(name="SALARY")
	private float empSal;
	public Employee()
	{
		
	}
	public Employee(int empId, String empNm, float empSal) {
		super();
		this.empId = empId;
		this.empNm = empNm;
		this.empSal = empSal;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpNm() {
		return empNm;
	}
	public void setEmpNm(String empNm) {
		this.empNm = empNm;
	}
	public float getEmpSal() {
		return empSal;
	}
	public void setEmpSal(float empSal) {
		this.empSal = empSal;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empNm=" + empNm + ", empSal=" + empSal + "]";
	}
	
}
