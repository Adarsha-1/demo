package com.cg.web.boot.service;

import java.util.List;

import com.cg.web.boot.dto.Employee;

public interface EmpService {
	public List<Employee> getEmpList();
	public Employee joinNewEmployee(Employee emp);
}
