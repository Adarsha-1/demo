package com.cg.web.boot.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.web.boot.dao.EmpDao;
import com.cg.web.boot.dto.Employee;

@Service
public class EmpServiceImpl implements EmpService{

	@Autowired
	private EmpDao dao;
	
	@Override
	public List<Employee> getEmpList() {
		// TODO Auto-generated method stub
		Iterable<Employee> empItr= dao.findAll();
		List<Employee> empList=new ArrayList<Employee>();
		empItr.forEach( emp-> {empList.add(emp);});
		return empList;
	}

	@Override
	public Employee joinNewEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return dao.save(emp);
	}

}
