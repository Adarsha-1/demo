package com.cg.boot.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

//http:localhost:8082/home.do
@RestController
public class MyController {
	@RequestMapping(value="/home.do")
	public String getHomePage()
	{
		return "Home";
	}
}
