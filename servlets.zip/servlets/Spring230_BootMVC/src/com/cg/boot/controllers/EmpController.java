package com.cg.boot.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;



//http://localhost:8082/empService/home.do
@Controller
@RequestMapping("/empService")
public class EmpController {
	
	/*@Autowired
	private EmpService service;*/
	
	@RequestMapping("/home.do")
	public String getHomePage()
	{
		System.out.println("enteres");
		return "Home";
	}
	
	/*@RequestMapping("/login.do")
	public String getLoginPage()
	{
		return "Login";
	}*/
	
	/*@RequestMapping("/authenticate.do")
	public String authenticate(HttpServletRequest req)
	{
		String userName=req.getParameter("userName");
		String pwd=req.getParameter("pwd");
		System.out.println("User Name: "+userName+"\n pwd: "+pwd);
		return "MainMenu";
	}
	public ModelAndView authenticate(@RequestParam("userName") String userName, @RequestParam("pwd") String pwd)
	{
		System.out.println("User Name: "+userName+"\n pwd: "+pwd);
		String fullName=service.authenticate(userName, pwd);
		ModelAndView mAndView;
		if(fullName!=null)
		{
			mAndView=new ModelAndView("MainMenu");
			mAndView.addObject("fullName",fullName);
		}
		else
		{
			mAndView=new ModelAndView("Login");
			mAndView.addObject("msg","Authentication failed. please do again");
		}
		return mAndView;
	}
	
	@RequestMapping("/empList.do")
	public ModelAndView getEmpList()
	{
		List<Emp> empList=null;
		try {
			empList = service.getEmpList();
		} 
		catch (EmpException e) {
			e.printStackTrace();
		}
		ModelAndView mAndView=new ModelAndView();
		mAndView.addObject("empList",empList);
		mAndView.setViewName("EmpList");
		return mAndView;
	}*/
}
