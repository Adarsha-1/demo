package dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import dto.EmployeeDTO;
import entity.EmployeeEntity;

public class EmployeeDAO {
	public void addEmployee(EmployeeDTO employee)
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpa");
		EntityManager em=emf.createEntityManager();
		EmployeeEntity entity=new EmployeeEntity();
		entity.setEmpId(employee.getEmpId());
		entity.seteName(employee.getEmpName());
		entity.setCity(employee.getCity());
		entity.setSalary(employee.getSalary());
		entity.setDoj(employee.getDoj());
		EntityTransaction tran=em.getTransaction();
		tran.begin();
		System.out.println("started");
		em.persist(entity);
		System.out.println("after");
		tran.commit();
		System.out.println("commited");
		em.close();
		emf.close();
		System.out.println("Inserted");
	}
	
	public void getEmployee(int empId)
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpa");
		EntityManager em=emf.createEntityManager();
		EmployeeEntity entity=em.find(EmployeeEntity.class, empId);
		if(entity!=null)
		{
			System.out.println(entity.getEmpId());
			System.out.println(entity.geteName());
		}
		else
		{
			System.out.println("record not found");
		}
		em.close();
		emf.close();
		System.out.println("fetch3ed");
	}
	
	public void updateEmployee(int empId,String newCity)
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpa");
		EntityManager em=emf.createEntityManager();
		EmployeeEntity entity=em.find(EmployeeEntity.class, empId);
		em.getTransaction().begin();
		
		entity.setCity(newCity);//create update in backend except primary key values
		em.getTransaction().commit();
		em.close();
		emf.close();
		System.out.println(entity.geteName());
		System.out.println("Updated");
	}

}
